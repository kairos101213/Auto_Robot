#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math

class AutonomousNav:
    def __init__(self):
        rospy.init_node('autonomous_nav')
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.rate = rospy.Rate(10)
        self.x = 0
        self.y = 0

    def odom_callback(self, data):
        self.x = data.pose.pose.position.x
        self.y = data.pose.pose.position.y

    def move_to(self, target_x, target_y):
        move = Twist()
        while not rospy.is_shutdown():
            dx = target_x - self.x
            dy = target_y - self.y
            distance = math.sqrt(dx**2 + dy**2)
            if distance < 0.1:
                break
            move.linear.x = 0.2
            self.pub.publish(move)
            self.rate.sleep()
        move.linear.x = 0
        self.pub.publish(move)

if __name__ == "__main__":
    nav = AutonomousNav()
    nav.move_to(2, 2)
