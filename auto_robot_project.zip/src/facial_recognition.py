import face_recognition
import cv2
import os

known_encodings = []
known_names = []

for file in os.listdir("models/known_faces"):
    if file.endswith(".jpg") or file.endswith(".png"):
        img = face_recognition.load_image_file(f"models/known_faces/{file}")
        enc = face_recognition.face_encodings(img)[0]
        known_encodings.append(enc)
        known_names.append(os.path.splitext(file)[0])

video_capture = cv2.VideoCapture(0)

while True:
    ret, frame = video_capture.read()
    rgb_frame = frame[:, :, ::-1]
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
    for face_encoding, face_location in zip(face_encodings, face_locations):
        matches = face_recognition.compare_faces(known_encodings, face_encoding)
        name = "Unknown"
        if True in matches:
            match_index = matches.index(True)
            name = known_names[match_index]
        top, right, bottom, left = face_location
        cv2.rectangle(frame, (left, top), (right, bottom), (0,255,0), 2)
        cv2.putText(frame, name, (left, top-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,255,0), 2)
    cv2.imshow('Video', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()
