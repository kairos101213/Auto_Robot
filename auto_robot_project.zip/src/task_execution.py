def execute_task(task_name):
    if task_name == "pickup_item":
        print("Picking up item...")
    elif task_name == "deliver_item":
        print("Delivering item...")
    elif task_name == "scan_face":
        print("Scanning face for recognition...")
    else:
        print(f"Executing custom task: {task_name}")
