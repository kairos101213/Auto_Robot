from navigation import AutonomousNav
from task_execution import execute_task

nav = AutonomousNav()

# Example workflow
nav.move_to(2,2)
execute_task("pickup_item")
execute_task("scan_face")
nav.move_to(0,0)
execute_task("deliver_item")
