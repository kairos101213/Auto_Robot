# Autonomous Robot Simulation Project

## Overview
Simulates an autonomous robot with navigation, task execution, and facial recognition using Python and ROS.

## Requirements
- Ubuntu 20.04
- ROS Noetic
- Gazebo
- Python 3.x packages: opencv-python, face_recognition, numpy, rospy

## Run
1. Launch ROS core:
    ```
    roscore
    ```
2. In a new terminal, run the launch file:
    ```
    roslaunch auto_robot_project robot_simulation.launch
    ```
3. Run the main Python script:
    ```
    python3 src/main.py
    ```
